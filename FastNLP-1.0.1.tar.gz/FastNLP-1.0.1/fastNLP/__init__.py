
from fastNLP.envs import *
from fastNLP.core import *

__version__ = '1.0.1'
