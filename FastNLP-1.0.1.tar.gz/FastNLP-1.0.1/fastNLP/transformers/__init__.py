"""
:mod:`transformers` 模块，包含了常用的预训练模型。
"""
