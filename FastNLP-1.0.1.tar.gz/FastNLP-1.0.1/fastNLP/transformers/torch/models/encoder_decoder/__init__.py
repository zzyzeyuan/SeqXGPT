__all__ = [
    "EncoderDecoderConfig",
]

from .configuration_encoder_decoder import EncoderDecoderConfig